// SDNController.cc
#include "SDNController.h"

Define_Module(SDNController);

SDNController::SDNController() {
    flowExpiryTimer = nullptr;
}

SDNController::~SDNController() {
    cancelAndDelete(flowExpiryTimer);
}

void SDNController::initialize() {
    // Initialize flow expiry timer
    flowExpiryTimer = new cMessage("flowExpiryTimer");
    scheduleAt(simTime() + 1.0, flowExpiryTimer);
}

void SDNController::handleMessage(cMessage *msg) {
    if (msg == flowExpiryTimer) {
        handleFlowExpiry();
        scheduleAt(simTime() + 1.0, flowExpiryTimer);
        return;
    }

    if (strcmp(msg->getName(), "SwitchJoin") == 0) {
        handleSwitchJoin(msg);
    }
    else if (strcmp(msg->getName(), "PacketIn") == 0) {
        handlePacketIn(msg);
    }
    else if (strcmp(msg->getName(), "ArpPacketIn") == 0) {
        handleArpPacketIn(msg);
    }

    delete msg;
}

void SDNController::handleSwitchJoin(cMessage *msg) {
    std::string dpid = msg->par("dpid").stringValue();
    int gateIndex = msg->getArrivalGate()->getIndex();  // Get gate index

    // Store mapping from dpid to gate index
    dpidToGateIndex[dpid] = gateIndex;

    // Initialize MAC-to-port and flow table
    macToPort[dpid] = std::map<std::string, int>();
    flowTables[dpid] = std::vector<FlowEntry>();

    installTableMiss(dpid);
}


void SDNController::installTableMiss(const std::string& dpid) {
    // Create table-miss flow entry
    FlowEntry missEntry;
    missEntry.priority = 0;  // Lowest priority
    missEntry.outPort = -1;  // Send to controller
    missEntry.idleTimeout = 0;  // Never expire
    missEntry.hardTimeout = 0;  // Never expire

    installFlow(dpid, missEntry);
}

void SDNController::handlePacketIn(cMessage *msg) {
    EV << "Controller received PacketIn from switch " << msg->par("dpid").stringValue() << endl;
    // Extract packet information
    std::string dpid = msg->par("dpid").stringValue();
    std::string srcMac = msg->par("srcMac").stringValue();
    std::string dstMac = msg->par("dstMac").stringValue();
    int inPort = msg->par("inPort");

    // Learn source MAC address
    macToPort[dpid][srcMac] = inPort;

    // Determine output port
    int outPort;
    if (macToPort[dpid].find(dstMac) != macToPort[dpid].end()) {
        outPort = macToPort[dpid][dstMac];
    } else {
        outPort = -2;  // Flood
    }

    // Create new flow entry
    FlowEntry entry;
    entry.inPort = inPort;
    entry.srcMac = srcMac;
    entry.dstMac = dstMac;
    entry.priority = 1;
    entry.outPort = outPort;
    entry.packetsMatched = 0;
    entry.idleTimeout = 30;  // 30 seconds idle timeout
    entry.hardTimeout = 300;  // 5 minutes hard timeout
    entry.lastMatchTime = simTime();
    entry.creationTime = simTime();

    // Install flow entry if not flooding
    if (outPort != -2) {
        installFlow(dpid, entry);
    }
}

void SDNController::installFlow(const std::string& dpid, const FlowEntry& entry) {
    if (dpidToGateIndex.find(dpid) == dpidToGateIndex.end()) {
        EV << "Unknown switch DPID: " << dpid << endl;
        return;  // Switch not found, prevent crash
    }

    int gateIndex = dpidToGateIndex[dpid];  // Get correct gate index

    // Create and send flow modification message to the right switch
    cMessage *flowMod = new cMessage("FlowMod");
    flowMod->addPar("dpid") = dpid.c_str();
    flowMod->addPar("inPort") = entry.inPort;
    flowMod->addPar("srcMac") = entry.srcMac.c_str();
    flowMod->addPar("dstMac") = entry.dstMac.c_str();
    flowMod->addPar("priority") = entry.priority;
    flowMod->addPar("outPort") = entry.outPort;
    flowMod->addPar("idleTimeout") = entry.idleTimeout.dbl();
    flowMod->addPar("hardTimeout") = entry.hardTimeout.dbl();

    // Send message to the correct switch
    send(flowMod, "switch$o", gateIndex);
}


void SDNController::handleFlowExpiry() {
    simtime_t currentTime = simTime();

    // Check each switch's flow table
    for (auto& switchTable : flowTables) {
        auto& flows = switchTable.second;

        // Remove expired flows
        flows.erase(
            std::remove_if(
                flows.begin(),
                flows.end(),
                [currentTime](const FlowEntry& entry) {
                    // Check idle timeout
                    if (entry.idleTimeout > 0 &&
                        (currentTime - entry.lastMatchTime) >= entry.idleTimeout) {
                        return true;
                    }
                    // Check hard timeout
                    if (entry.hardTimeout > 0 &&
                        (currentTime - entry.creationTime) >= entry.hardTimeout) {
                        return true;
                    }
                    return false;
                }
            ),
            flows.end()
        );
    }
}

void SDNController::handleArpPacketIn(cMessage *msg) {
    std::string dpid = msg->par("dpid").stringValue();
    std::string srcMac = msg->par("srcMac").stringValue();
    std::string dstMac = msg->par("dstMac").stringValue();
    std::string srcIp = msg->par("srcIp").stringValue();
    std::string dstIp = msg->par("dstIp").stringValue();
    std::string arpType = msg->par("arpType").stringValue();
    int inPort = msg->par("inPort");

    // Learn IP-to-MAC mapping
    ipToMac[srcIp] = srcMac;

    if (arpType == "request") {
        if (ipToMac.find(dstIp) != ipToMac.end()) {
            // Known target - send ARP reply
            sendArpReply(dpid, srcMac, srcIp, ipToMac[dstIp], dstIp, inPort);

            // Install bidirectional flow rules
            FlowEntry entry;
            entry.inPort = inPort;
            entry.srcMac = srcMac;
            entry.dstMac = ipToMac[dstIp];
            entry.priority = 2;
            entry.outPort = macToPort[dpid][ipToMac[dstIp]];
            entry.idleTimeout = 300;
            entry.hardTimeout = 3600;
            installFlow(dpid, entry);

            // Reverse direction
            FlowEntry reverseEntry = entry;
            reverseEntry.inPort = entry.outPort;
            reverseEntry.srcMac = ipToMac[dstIp];
            reverseEntry.dstMac = srcMac;
            reverseEntry.outPort = inPort;
            installFlow(dpid, reverseEntry);
        } else {
            // Unknown target - flood ARP request
            FlowEntry entry;
            entry.inPort = inPort;
            entry.srcMac = srcMac;
            entry.priority = 1;
            entry.outPort = -2; // Flood
            entry.idleTimeout = 10;
            entry.hardTimeout = 30;
            installFlow(dpid, entry);
        }
    }
}

void SDNController::sendArpReply(const std::string& dpid,
                               const std::string& senderMac,
                               const std::string& senderIp,
                               const std::string& targetMac,
                               const std::string& targetIp,
                               int inPort) {
    cMessage *arpReply = new cMessage("ArpReply");
    arpReply->addPar("arp") = true;
    arpReply->addPar("arpType") = "reply";
    arpReply->addPar("srcMac") = targetMac.c_str();
    arpReply->addPar("dstMac") = senderMac.c_str();
    arpReply->addPar("srcIp") = targetIp.c_str();
    arpReply->addPar("dstIp") = senderIp.c_str();

    FlowEntry entry;
    entry.inPort = -1;  // Any input port
    entry.srcMac = targetMac;
    entry.dstMac = senderMac;
    entry.priority = 2;
    entry.outPort = inPort;
    entry.idleTimeout = 300;
    entry.hardTimeout = 3600;
    installFlow(dpid, entry);

    send(arpReply, "switch$o", dpidToGateIndex[dpid]);
}

void SDNController::installArpFlow(const std::string& dpid,
                                 const std::string& senderMac,
                                 const std::string& targetMac,
                                 int inPort,
                                 int outPort) {
    FlowEntry entry;
    entry.inPort = inPort;
    entry.srcMac = senderMac;
    entry.dstMac = targetMac;
    entry.priority = 2; // Higher than default flows
    entry.outPort = outPort;
    entry.idleTimeout = 300; // 5 minutes
    entry.hardTimeout = 3600; // 1 hour
    installFlow(dpid, entry);
}
