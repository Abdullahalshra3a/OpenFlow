// OpenFlowSwitch.cc
#include "OpenFlowSwitch.h"
#include <omnetpp.h>
Define_Module(OpenFlowSwitch);

OpenFlowSwitch::OpenFlowSwitch() {
}

OpenFlowSwitch::~OpenFlowSwitch() {
}

void OpenFlowSwitch::initialize() {
    // Generate switch ID
    dpid = std::to_string(getId());

    // Notify controller of switch presence
    cMessage *joinMsg = new cMessage("SwitchJoin");
    joinMsg->addPar("dpid") = dpid.c_str();
    send(joinMsg, "controller$o");
}

void OpenFlowSwitch::handleMessage(cMessage *msg) {
    // Try to extract ARP information
    ArpInfo arpInfo;
    if (extractArpInfo(msg, arpInfo)) {
        handleArpPacket(msg);
        return;
    }

    if (strcmp(msg->getName(), "FlowMod") == 0) {
        handleFlowMod(msg);
    } else {
        handlePacket(msg);
    }
}

void OpenFlowSwitch::handleFlowMod(cMessage *msg) {
    // Create new flow entry from message parameters
    FlowEntry entry;
    entry.inPort = msg->par("inPort").longValue();  // Changed to longValue()
    entry.srcMac = msg->par("srcMac").stringValue();
    entry.dstMac = msg->par("dstMac").stringValue();
    entry.priority = msg->par("priority").longValue();  // Changed to longValue()
    entry.outPort = msg->par("outPort").longValue();   // Changed to longValue()
    entry.idleTimeout = msg->par("idleTimeout").doubleValue();
    entry.hardTimeout = msg->par("hardTimeout").doubleValue();
    entry.packetsMatched = 0;
    entry.lastMatchTime = simTime();
    entry.creationTime = simTime();

    // Add to flow table
    flowTable.push_back(entry);

    // Sort flow table by priority (highest first)
    std::sort(flowTable.begin(), flowTable.end(),
        [](const FlowEntry& a, const FlowEntry& b) {
            return a.priority > b.priority;
        });

    // Print flow table entry for debugging
    EV << "Flow Entry: "
       << " inPort=" << entry.inPort
       << " srcMac=" << entry.srcMac
       << " dstMac=" << entry.dstMac
       << " priority=" << entry.priority
       << " outPort=" << entry.outPort
       << " packetsMatched=" << entry.packetsMatched
       << " idleTimeout=" << entry.idleTimeout
       << " hardTimeout=" << entry.hardTimeout
       << endl;

    delete msg;
}
void OpenFlowSwitch::handlePacket(cMessage *msg) {
    EV << "Switch " << dpid << " received packet at t=" << simTime()
       << " on port " << msg->getArrivalGate()->getIndex() << endl;

    // Print all message parameters
    cClassDescriptor *descriptor = msg->getDescriptor();
    int numFields = descriptor->getFieldCount();

    EV << "Message parameters:\n";
    for (int i = 0; i < numFields; i++) {
        const char *fieldName = descriptor->getFieldName(i);
        std::string fieldValue = descriptor->getFieldValueAsString(omnetpp::any_ptr(msg), i, 0);
        EV << "  " << fieldName << " = " << fieldValue << "\n";
    }

    // Extract packet information
    std::string dstMac = msg->par("dstMac").stringValue();
    std::string srcMac = msg->par("srcMac").stringValue();
    int inPort = msg->getArrivalGate()->getIndex();

    // Find matching flow entry
    FlowEntry* matchingFlow = findMatchingFlow(srcMac, dstMac, inPort);

    // Check if packet is ARP
    if (msg->hasPar("packetType") && strcmp(msg->par("packetType").stringValue(), "ARP") == 0) {
            handleArpPacket(msg);
            return;
        }

    if (matchingFlow) {
        // Update flow entry statistics
        matchingFlow->packetsMatched++;
        matchingFlow->lastMatchTime = simTime();

        if (matchingFlow->outPort == -2) {
            // Flood packet
            for (int i = 0; i < gateSize("port$o"); i++) {
                if (i != inPort) {
                    cMessage *copy = msg->dup();
                    send(copy, "port$o", i);
                }
            }
        } else if (matchingFlow->outPort == -1) {
            // Send to controller
            sendToController(msg, srcMac, dstMac, inPort);
        } else {
            // Forward to specified port
            send(msg, "port$o", matchingFlow->outPort);
        }
    } else {
        // No matching flow - use table-miss entry
        sendToController(msg, srcMac, dstMac, inPort);
    }
}

void OpenFlowSwitch::sendToController(cMessage *msg,
                                    const std::string& srcMac,
                                    const std::string& dstMac,
                                    int inPort) {
    // Create packet-in message
    cMessage *packetIn = new cMessage("PacketIn");
    packetIn->addPar("dpid") = dpid.c_str();
    packetIn->addPar("srcMac") = srcMac.c_str();
    packetIn->addPar("dstMac") = dstMac.c_str();
    packetIn->addPar("inPort") = inPort;

    // Send to controller
    send(packetIn, "controller$o");

    // Delete original packet
    delete msg;
}
void OpenFlowSwitch::handleArpPacket(cMessage *msg) {
    ArpInfo arpInfo;
    if (!extractArpInfo(msg, arpInfo)) {
        delete msg;
        return;
    }

    int inPort = msg->getArrivalGate()->getIndex();

    // Find matching flow entry
    FlowEntry* matchingFlow = findMatchingFlow(arpInfo.srcMac, arpInfo.dstMac, inPort);

    if (matchingFlow) {
        matchingFlow->packetsMatched++;
        matchingFlow->lastMatchTime = simTime();

        if (matchingFlow->outPort == -2) {
            // Flood packet
            for (int i = 0; i < gateSize("port$o"); i++) {
                if (i != inPort) {
                    cMessage *copy = msg->dup();
                    send(copy, "port$o", i);
                }
            }
            delete msg;
        } else if (matchingFlow->outPort == -1) {
            // Send to controller
            sendArpToController(arpInfo, inPort);
            delete msg;
        } else {
            // Forward to specified port
            send(msg, "port$o", matchingFlow->outPort);
        }
    } else {
        // No matching flow - send to controller
        sendArpToController(arpInfo, inPort);
        delete msg;
    }
}



bool OpenFlowSwitch::extractArpInfo(cMessage *msg, ArpInfo& info) {
    // Check if this is an ARP message by checking parameter presence
    if (!msg->hasPar("arp") || !msg->par("arp").boolValue()) {
        return false;
    }

    // Extract ARP information from message parameters
    info.srcMac = msg->par("srcMac").stringValue();
    info.dstMac = msg->par("dstMac").stringValue();
    info.srcIp = msg->par("srcIp").stringValue();
    info.dstIp = msg->par("dstIp").stringValue();
    info.isRequest = strcmp(msg->par("arpType").stringValue(), "request") == 0;

    return true;
}

FlowEntry* OpenFlowSwitch::findMatchingFlow(const std::string& srcMac,
                                          const std::string& dstMac,
                                          int inPort) {
    // Search flow table for matching entry
    for (auto& entry : flowTable) {
        if ((entry.srcMac.empty() || entry.srcMac == srcMac) &&
            (entry.dstMac.empty() || entry.dstMac == dstMac) &&
            (entry.inPort == -1 || entry.inPort == inPort)) {
            return &entry;
        }
    }
    return nullptr;
}

void OpenFlowSwitch::sendArpToController(const ArpInfo& arpInfo, int inPort) {
    cMessage *packetIn = new cMessage("ArpPacketIn");
    packetIn->addPar("dpid") = dpid.c_str();
    packetIn->addPar("packetType") = "ARP";
    packetIn->addPar("inPort") = inPort;
    packetIn->addPar("srcMac") = arpInfo.srcMac.c_str();
    packetIn->addPar("dstMac") = arpInfo.dstMac.c_str();
    packetIn->addPar("srcIp") = arpInfo.srcIp.c_str();
    packetIn->addPar("dstIp") = arpInfo.dstIp.c_str();
    packetIn->addPar("arpType") = arpInfo.isRequest ? "request" : "reply";

    send(packetIn, "controller$o");
}
