// SDNController.h
#ifndef __SDNCONTROLLER_H_
#define __SDNCONTROLLER_H_

#include <omnetpp.h>
#include <map>
#include <string>
#include <algorithm>

using namespace omnetpp;

// Flow table entry structure
struct FlowEntry {
    // Match fields for the flow
    int inPort;
    std::string srcMac;
    std::string dstMac;

    // Priority of the flow rule
    int priority;

    // Counters for matched packets
    long packetsMatched;

    // Output port for matched packets
    int outPort;

    // Timeout values
    simtime_t idleTimeout;  // Remove if no packets match for this duration
    simtime_t hardTimeout;  // Remove after this duration regardless of matches

    // Last time a packet matched this entry
    simtime_t lastMatchTime;

    // Creation time of the entry
    simtime_t creationTime;
};

class SDNController : public cSimpleModule {
private:
    // MAC address to port mapping for each switch
    std::map<std::string, std::map<std::string, int>> macToPort;

    // Flow tables for each switch
    std::map<std::string, std::vector<FlowEntry>> flowTables;

    std::map<std::string, int> dpidToGateIndex;  // Map dpid to gate index

    // Map IP addresses to MAC addresses
    std::map<std::string, std::string> ipToMac;  // IP to MAC mapping

    // Periodic timer to check for expired flows
    cMessage *flowExpiryTimer;

protected:
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;

    // Handler for new switch connections
    void handleSwitchJoin(cMessage *msg);

    // Handler for packet-in messages
    void handlePacketIn(cMessage *msg);

    // Install flow entry in switch
    void installFlow(const std::string& dpid, const FlowEntry& entry);

    // Install table-miss entry
    void installTableMiss(const std::string& dpid);

    // Check and remove expired flows
    void handleFlowExpiry();

    void handleArpPacketIn(cMessage *msg);
    void installArpFlow(const std::string& dpid,
                           const std::string& senderMac,
                           const std::string& targetMac,
                           int inPort,
                           int outPort);
    void sendArpReply(const std::string& dpid,
                         const std::string& senderMac,
                         const std::string& senderIp,
                         const std::string& targetMac,
                         const std::string& targetIp,
                         int inPort);


public:
    SDNController();
    virtual ~SDNController();
};

#endif
