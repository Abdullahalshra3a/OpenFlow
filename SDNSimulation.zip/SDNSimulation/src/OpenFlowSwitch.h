// OpenFlowSwitch.h
#ifndef __OPENFLOWSWITCH_H_
#define __OPENFLOWSWITCH_H_

#include <omnetpp.h>
#include <map>
#include <string>
#include <vector>
#include <algorithm>
#include "SDNController.h" // Include this to get FlowEntry definition


using namespace omnetpp;



class OpenFlowSwitch : public cSimpleModule {
private:
    std::string dpid;  // Switch identifier
    std::vector<FlowEntry> flowTable;  // Flow table
    // Simple struct for ARP information
        struct ArpInfo {
            std::string srcMac;
            std::string dstMac;
            std::string srcIp;
            std::string dstIp;
            bool isRequest;  // true for request, false for reply
        };

protected:
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;

    // Process incoming packets
    void handlePacket(cMessage *msg);

    // Process flow modifications from controller
    void handleFlowMod(cMessage *msg);

    // Find matching flow entry for a packet
    FlowEntry* findMatchingFlow(const std::string& srcMac, const std::string& dstMac,int inPort);

    // Send packet to controller
    void sendToController(cMessage *msg,
                                const std::string& srcMac,
                                const std::string& dstMac,
                                int inPort);

    // New methods for ARP handling
    void handleArpPacket(cMessage *msg);
    bool extractArpInfo(cMessage *msg, ArpInfo& info);
    void sendArpToController(const ArpInfo& arpInfo, int inPort);

public:
    OpenFlowSwitch();
    virtual ~OpenFlowSwitch();
};

#endif
